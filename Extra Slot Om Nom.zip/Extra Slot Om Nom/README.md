# Extra Slot Om Nom

This demo doesn't include the moveset yet. I will update the mod once the moveset gets made.